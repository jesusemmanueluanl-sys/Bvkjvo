package com.jesus.rvh;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LodestoneTrackerComponent;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.GlobalPos;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;
import net.minecraft.command.argument.EntityArgumentType;

public class RunnerVsHunter implements ModInitializer {
    private enum Role { HUNTER, RUNNER }
    private static final Map<UUID, Role> ROLES = new HashMap<>();
    private static final Map<UUID, Integer> LIVES = new HashMap<>();
    private static final Map<UUID, DeathSpot> DEATH_SPOTS = new HashMap<>();
    private static final Random RANDOM = new Random();
    private static UUID hunterId;
    private static boolean running = false;
    private static final int STARTING_LIVES = 2;

    private record DeathSpot(ServerWorld world, double x, double y, double z, float yaw, float pitch) {}

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(literal("rvh")
                .then(literal("hunter").then(argument("player", EntityArgumentType.player()).executes(ctx -> {
                    ServerPlayerEntity p = EntityArgumentType.getPlayer(ctx, "player");
                    setRole(p, Role.HUNTER);
                    hunterId = p.getUuid();
                    ctx.getSource().sendFeedback(() -> Text.literal(p.getName().getString() + " ahora es Hunter."), true);
                    return 1;
                })))
                .then(literal("runner").then(argument("player", EntityArgumentType.player()).executes(ctx -> {
                    ServerPlayerEntity p = EntityArgumentType.getPlayer(ctx, "player");
                    setRole(p, Role.RUNNER);
                    if (Objects.equals(hunterId, p.getUuid())) hunterId = null;
                    ctx.getSource().sendFeedback(() -> Text.literal(p.getName().getString() + " ahora es Runner."), true);
                    return 1;
                })))
                .then(literal("random").executes(ctx -> {
                    List<ServerPlayerEntity> players = new ArrayList<>(ctx.getSource().getServer().getPlayerManager().getPlayerList());
                    if (players.size() < 2) { ctx.getSource().sendError(Text.literal("Se necesitan al menos 2 jugadores.")); return 0; }
                    Collections.shuffle(players);
                    ROLES.clear(); LIVES.clear(); DEATH_SPOTS.clear();
                    hunterId = players.get(0).getUuid();
                    for (int i = 0; i < players.size(); i++) setRole(players.get(i), i == 0 ? Role.HUNTER : Role.RUNNER);
                    ctx.getSource().sendFeedback(() -> Text.literal("Roles asignados al azar. Hunter: " + players.get(0).getName().getString()), true);
                    return 1;
                }))
                .then(literal("start").executes(ctx -> start(ctx.getSource())))
                .then(literal("stop").executes(ctx -> { stop(ctx.getSource().getServer(), "Partida detenida."); return 1; }))
                .then(literal("status").executes(ctx -> status(ctx.getSource())))
                .then(literal("lives").then(argument("amount", IntegerArgumentType.integer(1, 10)).executes(ctx -> {
                    int amount = IntegerArgumentType.getInteger(ctx, "amount");
                    for (UUID id : ROLES.keySet()) if (ROLES.get(id) == Role.RUNNER) LIVES.put(id, amount);
                    ctx.getSource().sendFeedback(() -> Text.literal("Vidas de Runner ajustadas a " + amount + "."), true);
                    return 1;
                })))
            )
        );

        ServerTickEvents.END_SERVER_TICK.register(RunnerVsHunter::tickTracker);
        ServerLivingEntityEvents.AFTER_DEATH.register(RunnerVsHunter::onDeath);
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (!running || ROLES.get(newPlayer.getUuid()) != Role.RUNNER) return;
            DeathSpot spot = DEATH_SPOTS.remove(newPlayer.getUuid());
            if (spot != null && LIVES.getOrDefault(newPlayer.getUuid(), 0) > 0) {
                newPlayer.teleport(spot.world(), spot.x(), spot.y(), spot.z(), java.util.Set.of(), spot.yaw(), spot.pitch());
                newPlayer.sendMessage(Text.literal("Has regresado a tu lugar de muerte. Vidas: " + LIVES.get(newPlayer.getUuid())), false);
            }
        });
    }

    private static void setRole(ServerPlayerEntity player, Role role) {
        ROLES.put(player.getUuid(), role);
        if (role == Role.RUNNER) LIVES.putIfAbsent(player.getUuid(), STARTING_LIVES);
        else LIVES.remove(player.getUuid());
    }

    private static int start(ServerCommandSource source) {
        if (hunterId == null || !ROLES.containsValue(Role.RUNNER)) {
            source.sendError(Text.literal("Primero asigna un Hunter y al menos un Runner con /rvh hunter y /rvh runner, o usa /rvh random."));
            return 0;
        }
        running = true;
        MinecraftServer server = source.getServer();
        for (ServerWorld world : server.getWorlds()) world.getGameRules().get(GameRules.KEEP_INVENTORY).set(true, server);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            Role role = ROLES.get(p.getUuid());
            if (role == null) continue;
            giveRandomPositiveEffect(p);
            if (role == Role.HUNTER) giveTracker(p);
            p.sendMessage(Text.literal(role == Role.HUNTER ? "Eres el HUNTER. ¡Encuentra a los Runner!" : "Eres RUNNER. ¡Escapa! Tienes 2 vidas.").formatted(role == Role.HUNTER ? Formatting.RED : Formatting.GREEN), false);
        }
        source.sendFeedback(() -> Text.literal("¡Runner vs Hunter ha comenzado! Keep Inventory activado."), true);
        return 1;
    }

    private static void giveRandomPositiveEffect(ServerPlayerEntity player) {
        List<RegistryEntry<StatusEffect>> effects = List.of(StatusEffects.SPEED, StatusEffects.HASTE, StatusEffects.STRENGTH,
            StatusEffects.JUMP_BOOST, StatusEffects.REGENERATION, StatusEffects.RESISTANCE, StatusEffects.FIRE_RESISTANCE,
            StatusEffects.WATER_BREATHING, StatusEffects.NIGHT_VISION, StatusEffects.ABSORPTION, StatusEffects.SATURATION);
        RegistryEntry<StatusEffect> effect = effects.get(RANDOM.nextInt(effects.size()));
        int level = RANDOM.nextInt(3);
        player.addStatusEffect(new StatusEffectInstance(effect, -1, level, false, true, true));
    }

    private static void giveTracker(ServerPlayerEntity hunter) {
        ItemStack compass = new ItemStack(Items.COMPASS);
        compass.set(DataComponentTypes.CUSTOM_NAME, Text.literal("Brújula Rastreadora").formatted(Formatting.AQUA, Formatting.BOLD));
        hunter.getInventory().insertStack(compass);
    }

    private static void tickTracker(MinecraftServer server) {
        if (!running || hunterId == null) return;
        ServerPlayerEntity hunter = server.getPlayerManager().getPlayer(hunterId);
        if (hunter == null) return;
        ServerPlayerEntity target = null;
        double best = Double.MAX_VALUE;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (ROLES.get(p.getUuid()) != Role.RUNNER || LIVES.getOrDefault(p.getUuid(), 0) <= 0) continue;
            if (p.getWorld() != hunter.getWorld()) continue;
            double d = hunter.squaredDistanceTo(p);
            if (d < best) { best = d; target = p; }
        }
        if (target == null) return;
        GlobalPos pos = GlobalPos.create(target.getWorld().getRegistryKey(), target.getBlockPos());
        for (int i = 0; i < hunter.getInventory().size(); i++) {
            ItemStack stack = hunter.getInventory().getStack(i);
            if (stack.isOf(Items.COMPASS) && stack.hasCustomName() && stack.getName().getString().equals("Brújula Rastreadora")) {
                stack.set(DataComponentTypes.LODESTONE_TRACKER, new LodestoneTrackerComponent(Optional.of(pos), true));
            }
        }
        if (server.getTicks() % 40 == 0) hunter.sendMessage(Text.literal("Runner más cercano: " + target.getName().getString() + " — " + target.getBlockPos().getX() + ", " + target.getBlockPos().getY() + ", " + target.getBlockPos().getZ()).formatted(Formatting.AQUA), true);
    }

    private static void onDeath(net.minecraft.entity.LivingEntity entity, DamageSource source) {
        if (!(entity instanceof ServerPlayerEntity runner) || !running || ROLES.get(runner.getUuid()) != Role.RUNNER) return;
        ServerWorld world = (ServerWorld) runner.getWorld();
        DEATH_SPOTS.put(runner.getUuid(), new DeathSpot(world, runner.getX(), runner.getY(), runner.getZ(), runner.getYaw(), runner.getPitch()));
        int left = Math.max(0, LIVES.getOrDefault(runner.getUuid(), STARTING_LIVES) - 1);
        LIVES.put(runner.getUuid(), left);
        ServerPlayerEntity killer = source.getAttacker() instanceof ServerPlayerEntity p ? p : null;
        if (killer != null && killer.getUuid().equals(hunterId)) {
            runner.sendMessage(Text.literal("El Hunter te eliminó. Vidas restantes: " + left), false);
        } else {
            runner.sendMessage(Text.literal("Muerte no causada por el Hunter. Vidas restantes: " + left), false);
        }
        if (left == 0) {
            DEATH_SPOTS.remove(runner.getUuid());
            runner.sendMessage(Text.literal("Te has quedado sin vidas."), false);
            boolean anyAlive = false;
            for (Map.Entry<UUID, Role> entry : ROLES.entrySet()) {
                if (entry.getValue() == Role.RUNNER && LIVES.getOrDefault(entry.getKey(), 0) > 0) { anyAlive = true; break; }
            }
            if (!anyAlive && killer != null && killer.getUuid().equals(hunterId)) {
                runner.getServer().getPlayerManager().broadcast(Text.literal("¡GANASTE, HUNTER! Todos los Runner fueron eliminados por el Hunter." ).formatted(Formatting.GOLD, Formatting.BOLD), false);
                running = false;
            } else if (!anyAlive) {
                runner.getServer().getPlayerManager().broadcast(Text.literal("Todos los Runner quedaron fuera, pero el Hunter no gana porque no los eliminó."), false);
                running = false;
            }
        }
    }

    private static int status(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        source.sendFeedback(() -> Text.literal("Estado: " + (running ? "EN CURSO" : "DETENIDA")), false);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            Role r = ROLES.get(p.getUuid());
            if (r != null) source.sendFeedback(() -> Text.literal(p.getName().getString() + ": " + r + (r == Role.RUNNER ? " — vidas: " + LIVES.getOrDefault(p.getUuid(), 0) : "")), false);
        }
        return 1;
    }

    private static void stop(MinecraftServer server, String message) {
        running = false; ROLES.clear(); LIVES.clear(); DEATH_SPOTS.clear(); hunterId = null;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) p.sendMessage(Text.literal(message), false);
    }
}
