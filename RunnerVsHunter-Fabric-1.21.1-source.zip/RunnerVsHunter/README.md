# Runner vs Hunter — Fabric 1.21.1

Proyecto fuente para Minecraft Java 1.21.1, Fabric y Java 21.

## Compilar
1. Instala Java 21.
2. Instala Gradle 8.10.2 o usa un wrapper de Gradle compatible.
3. Abre una terminal dentro de esta carpeta y ejecuta: `gradle build`.
4. El JAR se genera en `build/libs/runner-vs-hunter-1.0.0.jar`.
5. Instala Fabric Loader 1.21.1 y Fabric API 0.102.1+1.21.1; copia el JAR a `mods`.

## Comandos
- `/rvh hunter <jugador>` — asigna Hunter.
- `/rvh runner <jugador>` — asigna Runner.
- `/rvh random` — elige un Hunter al azar y el resto son Runner.
- `/rvh start` — inicia, activa keepInventory, da efectos y rastreador.
- `/rvh status` — muestra roles y vidas.
- `/rvh lives <cantidad>` — cambia las vidas de los Runner.
- `/rvh stop` — detiene y limpia la partida.

## Reglas implementadas
- Dos vidas iniciales por Runner.
- Al morir, Runner pierde una vida y reaparece en la ubicación de su muerte si conserva vidas.
- Solo se anuncia victoria del Hunter cuando el último Runner pierde su última vida por daño atribuido al Hunter.
- Cada jugador recibe un efecto positivo aleatorio con duración infinita y amplificador aleatorio I–III.
- El Hunter recibe una brújula rastreadora que actualiza su destino hacia el Runner vivo más cercano en la misma dimensión; también muestra coordenadas en acción.
- `keepInventory` se activa al iniciar.

## Nota
Este proyecto fuente todavía necesita compilarse y probarse en una instancia real. El seguimiento de brújula usa el componente Lodestone de Minecraft 1.21.1. Los roles y vidas se guardan en memoria y se reinician al apagar el servidor o ejecutar `/rvh stop`.
